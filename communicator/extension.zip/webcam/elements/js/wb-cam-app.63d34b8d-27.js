
Polymer({
    is: "paper-icon-item",
    behaviors: [Polymer.PaperItemBehavior]
});
