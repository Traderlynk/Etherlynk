
Polymer({
    is: "paper-spinner-lite",
    behaviors: [Polymer.PaperSpinnerBehavior]
});
