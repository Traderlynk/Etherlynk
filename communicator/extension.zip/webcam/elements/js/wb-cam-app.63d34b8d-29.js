
Polymer({
    is: "paper-item",
    behaviors: [Polymer.PaperItemBehavior]
});
