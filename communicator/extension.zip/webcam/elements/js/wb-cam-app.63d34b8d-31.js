
! function() {
    Polymer({
        is: "paper-menu",
        behaviors: [Polymer.IronMenuBehavior]
    })
}();
