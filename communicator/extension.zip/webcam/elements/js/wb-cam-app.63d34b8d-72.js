
! function() {
    Polymer({
        is: "paper-listbox",
        behaviors: [Polymer.IronMenuBehavior],
        hostAttributes: {
            role: "listbox"
        }
    })
}();
