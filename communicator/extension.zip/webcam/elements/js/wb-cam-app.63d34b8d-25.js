
Polymer({
    is: "paper-input",
    behaviors: [Polymer.IronFormElementBehavior, Polymer.PaperInputBehavior]
});
