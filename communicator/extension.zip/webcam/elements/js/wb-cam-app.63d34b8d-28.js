
Polymer({
    is: "paper-item-body"
});
